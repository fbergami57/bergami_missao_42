#!/bin/bash
# Check if any arguments are provided
if [ -z "$1" ]; then
    echo "No arguments supplied"
    exit 1
fi
# Loop through the arguments and create the folders
for arg in "$@"; do
    folder_name="ex$arg"
    mkdir "$folder_name"
done
