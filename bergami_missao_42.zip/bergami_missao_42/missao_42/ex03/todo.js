 // Função para carregar as tarefas do cookie
 function loadTasksFromCookie() {
    const tasksString = getCookie('tasks');
    if (tasksString) {
      const tasks = JSON.parse(tasksString);
      tasks.forEach(task => addTask(task));
    }
  }

  // Função para salvar as tarefas no cookie
  function saveTasksToCookie() {
    const tasks = Array.from(document.querySelectorAll('#ft_list .task')).map(task => task.textContent);
    setCookie('tasks', JSON.stringify(tasks), 365);
  }

  // Função para adicionar uma nova tarefa
  function addTask(taskText) {
    const taskDiv = document.createElement('div');
    taskDiv.classList.add('task');
    taskDiv.textContent = taskText;
    taskDiv.addEventListener('click', removeTask);
    document.getElementById('ft_list').prepend(taskDiv);
    saveTasksToCookie();
  }

  // Função para remover uma tarefa
  function removeTask(event) {
    if (confirm('Deseja remover esta tarefa?')) {
      event.target.remove();
      saveTasksToCookie();
    }
  }

  // Funções auxiliares para manipulação de cookies
  function getCookie(name) {
    const value = `; ${document.cookie}`;
    const parts = value.split(`; ${name}=`);
    if (parts.length === 2) return parts.pop().split(';').shift();
  }

  function setCookie(name, value, days) {
    const date = new Date();
    date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
    document.cookie = `${name}=${value}; expires=${date.toUTCString()}; path=/`;
  }

  // Carregar tarefas do cookie ao carregar a página
  loadTasksFromCookie();

  // Adicionar evento de clique no botão "Adicionar Tarefa"
  document.getElementById('addTask').addEventListener('click', () => {
    const taskText = prompt('Digite uma nova tarefa:');
    if (taskText) {
      addTask(taskText);
    }
  });

  /*
  1 - As tarefas são salvas e carregadas de um cookie chamado "tasks".
2 - A função loadTasksFromCookie() carrega as tarefas do cookie e as adiciona à lista.
3 - A função addTask(taskText) cria uma nova tarefa e a adiciona no topo da lista.
4 - A função removeTask(event) remove uma tarefa da lista após confirmação do usuário.
5 - As funções getCookie(name) e setCookie(name, value, days) são responsáveis pela manipulação dos cookies.
6 - O botão "Adicionar Tarefa" abre um prompt para o usuário inserir uma nova tarefa.
7 - Ao fechar e abrir o navegador, a lista de tarefas será carregada a partir do cookie salvo.
*/