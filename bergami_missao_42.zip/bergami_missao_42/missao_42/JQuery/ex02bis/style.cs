body {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  margin: 0;
  background-color: #f0f0f0;
}

.calculator-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  background-color: white;
  padding: 30px;
  border-radius: 8px;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
}

.calculator-container input,
.calculator-container select,
.calculator-container button {
  margin: 10px;
  padding: 8px 12px;
  font-size: 16px;
  width: 200px;
  text-align: center;
  border: 1px solid #ccc;
  border-radius: 4px;
}

.calculator-container input::placeholder,
.calculator-container select::placeholder {
  text-align: center;
}

.calculator-container button {
  background-color: #4CAF50;
  color: white;
  cursor: pointer;
}

.calculator-container button:hover {
  background-color: #45a049;
}
