$(document).ready(function() {
    const $balloon = $('#balloon');
    let size = 200;
    let color = 'red';
    let colors = ['red', 'green', 'blue'];
    let colorIndex = 0;
  
    $balloon.on('click', function() {
      size += 10;
      if (size > 420) {
        size = 200;
      }
      color = colors[colorIndex];
      colorIndex = (colorIndex + 1) % colors.length;
      $balloon.css({
        'width': size + 'px',
        'height': size + 'px',
        'background-color': color
      });
    });
  
    $balloon.on('mouseenter', function() {
      size += 5;
      if (size > 420) {
        size = 200;
      }
      colorIndex = (colorIndex - 1 + colors.length) % colors.length;
      color = colors[colorIndex];
      $balloon.css({
        'width': size + 'px',
        'height': size + 'px',
        'background-color': color
      });
    });
  
    $balloon.on('mouseleave', function() {
      size -= 5;
      if (size < 200) {
        size = 200;
      }
      colorIndex = (colorIndex - 1 + colors.length) % colors.length;
      color = colors[colorIndex];
      $balloon.css({
        'width': size + 'px',
        'height': size + 'px',
        'background-color': color
      });
    });
  });
  /*The main differences are:

Wrapped the entire code in a $(document).ready() function to ensure the DOM is fully loaded before the code runs.
Used $('#balloon') to select the balloon element instead of document.getElementById('balloon').
Used jQuery's on() method to attach the event listeners instead of addEventListener().
Used jQuery's css() method to update the balloon's styles instead of directly setting the style property.*/