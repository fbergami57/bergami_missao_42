// Get the necessary DOM elements
const leftOperand = document.getElementById('left-operand');
const rightOperand = document.getElementById('right-operand');
const operator = document.getElementById('operator');
const calculateButton = document.getElementById('calculate-btn');

// Function to perform the calculation
function performCalculation() {
  const left = parseInt(leftOperand.value);
  const right = parseInt(rightOperand.value);
  const op = operator.value;

  // Validate input
  if (isNaN(left) || isNaN(right) || left < 0 || right < 0) {
    alert('Error :(');
    return;
  }

  let result;
  switch (op) {
    case '+':
      result = left + right;
      break;
    case '-':
      result = left - right;
      break;
    case '*':
      result = left * right;
      break;
    case '/':
      if (right === 0) {
        alert("It's over 9000!");
        console.log("It's over 9000!");
        return;
      }
      result = left / right;
      break;
    case '%':
      if (right === 0) {
        alert("It's over 9000!");
        console.log("It's over 9000!");
        return;
      }
      result = left % right;
      break;
    default:
      alert('Error :(');
      return;
  }

  alert(result);
  console.log(result);
}

// Add event listener to the calculate button
calculateButton.addEventListener('click', performCalculation);

// Display a pop-up every 30 seconds
setInterval(() => {
  alert('Please, use me...');
}, 30000);
