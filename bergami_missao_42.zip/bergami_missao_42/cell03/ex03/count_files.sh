#!/bin/bash
find . -maxdepth 3 -type f | wc -l && find . -maxdepth 3 -type d | wc –l 
