function changeBackground() {
    // Gera uma cor hexadecimal aleatória
    var randomColor = '#' + Math.floor(Math.random() * 16777215).toString(16);
    
    // Define a cor de fundo do elemento body
    document.body.style.backgroundColor = randomColor;
}