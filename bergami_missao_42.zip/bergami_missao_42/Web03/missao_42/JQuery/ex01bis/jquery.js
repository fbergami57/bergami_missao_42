let balloonSize = 200;
let balloonColors = ['red', 'green', 'blue'];
let colorIndex = 0;

$('#balloon').click(function() {
  balloonSize += 10;
  if (balloonSize > 420) {
    balloonSize = 200;
  }
  $(this).css({
    'width': balloonSize + 'px',
    'height': balloonSize + 'px',
    'background-color': balloonColors[colorIndex]
  });
  colorIndex = (colorIndex + 1) % balloonColors.length;
});

$('#balloon').hover(
  function() {
    // Increase balloon size when mouse enters
    balloonSize += 5;
    if (balloonSize > 420) {
      balloonSize = 420;
    }
    $(this).css({
      'width': balloonSize + 'px',
      'height': balloonSize + 'px',
      'background-color': balloonColors[colorIndex]
    });
  },
  function() {
    // Decrease balloon size when mouse leaves
    balloonSize -= 5;
    if (balloonSize < 200) {
      balloonSize = 200;
    }
    colorIndex = (colorIndex - 1 + balloonColors.length) % balloonColors.length;
    $(this).css({
      'width': balloonSize + 'px',
      'height': balloonSize + 'px',
      'background-color': balloonColors[colorIndex]
    });
  }
);

  /*The main differences are:

Wrapped the entire code in a $(document).ready() function to ensure the DOM is fully loaded before the code runs.
Used $('#balloon') to select the balloon element instead of document.getElementById('balloon').
Used jQuery's on() method to attach the event listeners instead of addEventListener().
Used jQuery's css() method to update the balloon's styles instead of directly setting the style property.*/