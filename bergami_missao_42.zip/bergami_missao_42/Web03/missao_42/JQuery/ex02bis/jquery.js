$(document).ready(function() {
    // Get the necessary DOM elements
    const $leftOperand = $('#left-operand');
    const $rightOperand = $('#right-operand');
    const $operator = $('#operator');
    const $calculateButton = $('#calculate-btn');
  
    // Function to perform the calculation
    function performCalculation() {
      const left = parseInt($leftOperand.val());
      const right = parseInt($rightOperand.val());
      const op = $operator.val();
  
      // Validate input
      if (isNaN(left) || isNaN(right) || left < 0 || right < 0) {
        alert('Error :(');
        return;
      }
  
      let result;
      switch (op) {
        case '+':
          result = left + right;
          break;
        case '-':
          result = left - right;
          break;
        case '*':
          result = left * right;
          break;
        case '/':
          if (right === 0) {
            alert("It's over 9000!");
            console.log("It's over 9000!");
            return;
          }
          result = left / right;
          break;
        case '%':
          if (right === 0) {
            alert("It's over 9000!");
            console.log("It's over 9000!");
            return;
          }
          result = left % right;
          break;
        default:
          alert('Error :(');
          return;
      }
  
      alert(result);
      console.log(result);
    }
  
    // Add event listener to the calculate button
    $calculateButton.click(performCalculation);
  
    // Display a pop-up every 30 seconds
    setInterval(function() {
      alert('Please, use me...');
    }, 30000);
  });
  