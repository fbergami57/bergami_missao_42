const balloon = document.getElementById('balloon');
let size = 200;
let color = 'red';
let colors = ['red', 'green', 'blue'];
let colorIndex = 0;

balloon.addEventListener('click', () => {
  size += 10;
  if (size > 420) {
    size = 200;
  }
  color = colors[colorIndex];
  colorIndex = (colorIndex + 1) % colors.length;
  balloon.style.width = `${size}px`;
  balloon.style.height = `${size}px`;
  balloon.style.backgroundColor = color;
});

balloon.addEventListener('mouseenter', () => {
  colorIndex = (colorIndex - 1 + colors.length) % colors.length;
  color = colors[colorIndex];
  balloon.style.width = `${size}px`;
  balloon.style.height = `${size}px`;
  balloon.style.backgroundColor = color;
});

balloon.addEventListener('mouseleave', () => {
  size -= 5;
  if (size > 420) {
    size = 200;
  }
  colorIndex = (colorIndex - 1 + colors.length) % colors.length;
  color = colors[colorIndex];
  balloon.style.width = `${size}px`;
  balloon.style.height = `${size}px`;
  balloon.style.backgroundColor = color;
});
